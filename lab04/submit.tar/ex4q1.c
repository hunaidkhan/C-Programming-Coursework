#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(){
    char crop = ' ';
    float profit = 0;
 
    
    while(scanf("%c", &crop) != EOF){
        if(crop=='/'){
            char cropType;
            scanf("%c", &cropType);

            if(cropType=='C'){
                profit += (0.50 - 0.05);
            }
            if(cropType=='T'){
                profit += (1.25 - 0.25);
            }
            if(cropType=='P'){
                profit += (3 - 0.7);
            }
            if(cropType=='L'){
                profit += (1 - 0.3);
            }
        }
        else if(crop== '#'){
            char cropType;
            scanf("%c", &cropType);

            if(cropType=='C'){
                profit -= 0.05;
            }
            if(cropType=='T'){
                profit -= 0.25;
            }
            if(cropType=='P'){
                profit -= 0.70;
            }
            if(cropType=='L'){
                profit -= 0.30;
            }
        }
    }
    if(profit < 0){
        profit = -profit;
        printf("Net profit: -$%.2f\n", profit);
    }
    else{
        printf("Net profit: $%.2f\n", profit);
    }
}