#include <stdio.h>

int main() {
    int n=0;
    scanf("%d", &n);

    float boxes[1999] = {};
    for(int i=0; i<n; i++){
        scanf("%f", &boxes[i]);
    }
    //bubble sorting
    for(int i=0; i<n; i++){
        for(int j=0; j<n-i-1; j++){
            if(boxes[j] > boxes[j+1]){
                float temp = boxes[j];
                boxes[j] = boxes[j+1];
                boxes[j+1] = temp;
            }
        }
    }
    for(int i=0; i<n; i++){
        // printf("%.1f ", boxes[i]);
    }
    float truck_weight = 0;
    while(scanf("%f", &truck_weight)!=EOF){
        //binary search on the boxes array
        int left = 0;
        int right = n-1;
        int mid = (left+right)/2;
        while(left<=right){
            if(boxes[mid] <= truck_weight && boxes[mid+1] > truck_weight){
                break;
            }
            else if(boxes[mid] < truck_weight){
                left = mid+1;
            }
            else{
                right = mid-1;
            }
            mid = (left+right)/2;
        }

        int total_boxes = 0;
        float total_weight= 0;
        // printf("mid - %d   total_boxes = %d\n", mid, total_boxes);
        for(int i =0; i<=mid;i++){
            total_weight += boxes[i];
            // printf("total_weight = %f\n", total_weight);
            if(total_weight <= truck_weight){
                total_boxes += 1;
            }
            else{
                break;
            }
        }
        printf("%d\n", total_boxes);
    }
}
