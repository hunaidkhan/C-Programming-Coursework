#include <stdio.h>
#include <stdlib.h>

int main(){
    int hardcover, softcover, ebook;
    printf("How many hardcover books are you buying? ");
    scanf("%d", &hardcover);
    printf("How many softcover books are you buying? ");
    scanf("%d", &softcover);
    printf("How many ebooks are you buying? ");
    scanf("%d", &ebook);

    //validating input
    if((hardcover <=0 || hardcover >=100000) || (softcover <=0 || softcover >=100000) || (ebook <=0 || ebook >=100000)){
        exit(100);
    }
    float totalAmount = 15*hardcover + 12*softcover + 7*ebook;


    //coupon discounts
    int couponDiscounts = 0;
    if(hardcover>=2){
        couponDiscounts += 5;
    }
    if(softcover >=4 ){
        couponDiscounts += 10;
    }
    if((hardcover + softcover) >= 6){
        couponDiscounts += 20;
    }

    totalAmount -= couponDiscounts;

    //percentage discounts
    float percentageDiscount = 0;
    if(hardcover>=1 && softcover >=1 && ebook>=1){ //3% off the final discounted total, if the order includes at least 1 hardcover, 1 softcover, and 1 ebook
        percentageDiscount += 3;
    }
    if(ebook>=3){ //4% off the final discounted total, if the order includes 3 or more ebooks
        percentageDiscount += 4;
    }
    if(totalAmount > 75) //10% off the final discounted total, on orders over $75
    {
        percentageDiscount += 10;
    }
    if(totalAmount>150){  //15% off the final discounted total, on orders over $150
        percentageDiscount += 15;
    }


    totalAmount = totalAmount - totalAmount*(percentageDiscount/100);

    printf("Order total: $%.2f\n", totalAmount);

}