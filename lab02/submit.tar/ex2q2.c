#include <stdio.h>
#include <math.h>
#include <stdlib.h>

int main(){
    int cadAmount;
    printf("Enter CAD amount: ");
    scanf("%d", &cadAmount);
    
    if(!((cadAmount <100000) && (cadAmount > 0))){
        exit(100);
    }

   
    float usdAmount = 0.75*cadAmount; //float amount
    int usdAmountInt = 0.75*cadAmount; //int amount

    if((usdAmount - usdAmountInt) <0.5){ //round down
        usdAmount = usdAmountInt;
    }
    else if((usdAmount - usdAmountInt) >=0.5){ // round up
        usdAmountInt = usdAmountInt + 1;
        usdAmount = usdAmountInt;
    }
  
    printf("Converted USD amount: $%d\n", usdAmountInt);

    //100 dollar bills
    int newAmount= usdAmount/100; 
    printf("$100 bills: %d\n", newAmount);
    usdAmount -= newAmount*100;
    //50 dollar bills
    newAmount = usdAmount/50;
    printf("%4s bills: %d\n", "$50" , newAmount);
    usdAmount -= newAmount *50;
    //20 dollar bills
    newAmount = usdAmount/20;
    printf("%4s bills: %d\n","$20" ,newAmount);
    usdAmount -= newAmount *20;
    //10 dollar bills
    newAmount = usdAmount/10;
    printf("%4s bills: %d\n", "$10" , newAmount);
    usdAmount -= newAmount *10;
    //5 dollar bills
    newAmount = usdAmount/5;
    printf("%4s bills: %d\n", "$5" ,newAmount);
    usdAmount -= newAmount *5;
    //2 dollar bills
    newAmount = usdAmount/2;
    printf("%4s bills: %d\n","$2" , newAmount);
    usdAmount -= newAmount *2;
    //1 dollar bills
    newAmount = usdAmount/1;
    printf("%4s bills: %d\n", "$1" ,newAmount);
}