#include "ex8q1.h"
#include <stdlib.h>
#include <stdio.h>

int main(void) {
    int is_print, value;
    float index;
    float *indices_array = (float *)malloc(0);
    int indices_length = 0;
    int *values_array = (int *)malloc(0);
    int values_length = 0;

    while (!feof(stdin)) {
        // Use the read_line function from ex7q1.h here! Do not try to parse the
        // input yourself (that's a lot harder)

        
        read_line(&is_print, &index, &value);
        // fprintf(stderr, "%d %0.4f %d\n", is_print, index, value);  // You can remove this

        if(is_print == 1){
            printf("[");
            for(int i =0; i<values_length;i++){
                printf("%d", values_array[i]);
                if(i != values_length-1){
                    printf(", ");
                }
            }
            printf("]\n");
        }

        if(is_print == 0){
            //assign value
            int index_present = 0;
            //checking if index is already allocated
            for(int i =0;i<indices_length;i++){

                if(indices_array[i] == index){ //if index is already present in the indices array
                    // printf("REPlacing\n");
                    values_array[i] = value;
                    index_present = 1;
                    break;
                }
            }
            //if index is not present in the indices array
            if(index_present == 0){ //reallocating memory for indices array
                // printf("Reallocating memory\n");
                if(indices_length == 0){
                    // printf("Array is empty\n");
                    indices_array = (float *)realloc(indices_array, sizeof(float));
                    values_array = (int *)realloc(values_array, sizeof(int));
                    indices_array[0] = index;
                    values_array[0] = value;
                    indices_length++;
                    values_length++;
                    // printf("First element - %d", values_array[0]);
                    continue;
                }
              
                for(int i = 0;i<indices_length;i++){
                    if(indices_array[i] > index){
                        //shifting all elements to the right
                       
                        
                        
                        indices_array = (float *)realloc(indices_array, indices_length + sizeof(float));
                        values_array = (int *)realloc(values_array, values_length + sizeof(int));
                        for(int j = indices_length-1;j>=i;j--){
                            indices_array[j+1] = indices_array[j];
                            values_array[j+1] = values_array[j];
                        }
                        indices_length++;
                        values_length++;
                        indices_array[i] = index;
                        values_array[i] = value;
                        // printf("index - %f value - %d\n", indices_array[i], values_array[i]);
                        break;
                    }
                    else{
                        if(i == indices_length-1){
                            indices_array = (float *)realloc(indices_array, indices_length*sizeof(float) + sizeof(float));
                            values_array = (int *)realloc(values_array, values_length*sizeof(int) + sizeof(int));
                            indices_array[i+1] = index;
                            values_array[i+1] = value;
                            indices_length++;
                            values_length++;
                            // printf("index - %f value - %d\n", indices_array[i+1], values_array[i+1]);
                            break;
                        }
                    }
                }
                
            }
        }
       


        
    }
}
