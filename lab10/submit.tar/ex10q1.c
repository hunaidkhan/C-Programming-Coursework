#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int* head;
    int* start;
    int* end;
    int length;
    int capacity;
} Ring;

void initialize(Ring* r){
    r->capacity = 10;
    r->head = (int *)malloc(sizeof(int) * r->capacity);
    r->start = r->head;
    r->end = r->head;
    r->length = 0;
}
void doubleMemory(Ring* r){
    r->capacity *= 2;
    int* newHead = (int*)realloc(r->head, r->capacity * sizeof(int));
    r->start = newHead + (r->start - r->head);
    r->end = newHead + (r->length)+1;
    free(r->head);
    r->head = newHead;
}

void exchange(int* start, int* end){
    int temp = *start;
    *start = *end;
    *end = temp;
}

void pushBack(Ring* r, int student_id){
    if (r->length == r->capacity) {
        doubleMemory(r);
        // Double the capacity
        // r->capacity *= 2;
        // int* newHead = (int*)realloc(r->head, r->capacity * sizeof(int));

        // if (newHead == NULL) {
        //     // Handle memory allocation failure
        //     fprintf(stderr, "Memory allocation failed\n");
        //     exit(EXIT_FAILURE);
        // }

        // Update pointers
        // r->start = newHead + (r->start - r->head);
        // r->end = newHead + (r->length)+1;
        // free(r->head);
        // r->head = newHead;

     
    }

    // Push the value to the back
    *(r->end) = student_id;
    r->end++;

    // Wrap around if needed
    if (r->end == r->head + r->capacity) {
        r->end = r->head;
    }

    r->length++;
    // printf("Head - %d Start - %d End - %d\n", *r->head, *r->start, *(r->end));
   
}

void pushFront(Ring* r, int student_id){
    //implement the push front in circulal queue
    if (r->length == r->capacity) {
        printf("i am doubling memory");
        doubleMemory(r);
        // r->capacity *= 2;
        // int* newHead = (int*)realloc(r->head ,r->capacity * sizeof(int));
        // free(r->head);
        // r->head = newHead;
        // r->end = r->head + r->length;
    }
    exchange(r->start, r->start + 1);

    // r->start--;
    *r->start = student_id;
    r->length++;
    // printf("Head - %d Start - %d End - %d\n", *r->head, *r->start, *(r->end));
}

void slideIndexes(Ring* front, Ring* back, int partition){
    front->start = back->start;
    front->end = back->start + partition - 1;
    front->length = partition;
    back->start = front->end + 1;
    back->length -= partition;
    // printf("\nFonrt start- %d, Fornt end - %d\n", *front->start, *front->end);
    // printf("back start- %d, back end - %d\n\n", *back->start, *back->end);
}

void printInOrder(Ring* ring){
    
    if (ring->length == 0) {
        printf("Ring buffer is empty\n");
        return;
    }

    int* current = ring->start;
    printf("[");
    for (int i = 0; i < ring->length; i++) {
        // printf("%d ",current);

        current++;
        // Wrap around if needed
        if (current == ring->head + ring->capacity) {
            current = ring->head;
        }
    }
    printf("]");

    printf("\n");

}

void popFront(Ring* ring){
    
    if(ring->length > 0){
        int temp = *ring->start ;
        printf("%d\n", temp);
  
        ring->start++;
        ring->length--;

    }
    
}

void popBack(Ring* ring){
    
    if(ring->length > 0){
       if (ring->length > 0) {
        // Move the end pointer back
        // printf("LFet elemetnd %d\n", *(ring->end-1));
        ring->end--;

        // Wrap around if needed
        // if (ring->end < ring->head) {
        //     ring->end = ring->head + ring->capacity - 1;
        // }

        ring->length--;
    }
    }
}

// void rebalance(Ring* front, Ring* back){
//     int temp  = *(front->end-1);
//     *(front->end - 1) =  back->start;
//     *(back->start) = temp;
// }



void freeMemory(Ring* r){
    free(r->head);
}

int main() {
    Ring front, back;
    initialize(&front);  
    initialize(&back);
    
    // front.head = back.head;
    // printf("INitial lenfth %d %d", front.length, back.length);
    // printAutographs(&front, &back);

    // Read input and process
    
    // printf("%d", front.length);
    char action;
    int x, student_id;

    while (scanf("%c", &action) == 1) {
    
        if (action == 'N') {
            scanf("%d %d", &x, &student_id);
            // if(init_flag == 1){
            //     if(front.length == 0) initialize(&front);
            //     if(back.length == 0) initialize(&back);
            // }
            if (front.length + back.length < x) {
                if(front.length == 0 && back.length == 0){
                    pushBack(&front, student_id);
                }
                else if(front.length == 1 && back.length == 0){
                    pushFront(&back, student_id);
                }
                else if(front.length == 1 && back.length == 1){
                    pushBack(&front, student_id);
                    exchange(front.end - 1, back.start);
                }
                else if(front.length == back.length){
                    pushBack(&front, student_id);
                    exchange(front.end-1, back.start);
                    if(back.length >=3){
                        // printf("I am in here\n");
                        for(int* i=back.start;i<back.end-1;i++){
                            // printf("i - %d", i);
                            exchange(i, i+1);
                        }
                    }
                    else{
                        // exchange(back.start, back.end-1);
                    }
                    // int temp = *(front.end - 1);
                    // *(front.end-1) = *back.start;
                    // *back.start = temp;
            //  [11,22,33,44 | 66,55,77]
                }
                else if(front.length > back.length){
                    pushFront(&back, student_id);
                    // exchange(front.end-1, back.start);
                    // exchange(back.start, back.end-1);
                    for(int* i=back.start;i<back.end-1;i++){
                            // printf("i - %d", i);
                            exchange(i, i+1);
                     }
                }
                else if (front.length < back.length){
                    pushBack(&front, student_id);
                    exchange(front.end-1, back.start );
                    for(int* i=back.start;i<back.end-1;i++){
                            // printf("i - %d", i);
                            exchange(i, i+1);
                     }
                }
                // printf("\nFonrt start- %d, Fornt end - %d\n", *front.start, *(front.end-1));
                // printf("back start- %d, back end - %d\n\n", *back.start, *(back.end-1));
                // printf("Front length: %d, back klength: %d\n", front.length, back.length);
            }
        } else if (action == 'C') { 
            scanf("%d %d", &x, &student_id);
            int total_length = front.length + back.length;
            if((total_length)%2 == 0){
                total_length = total_length/2;
            }
            else if(total_length%2 != 0){
                total_length = total_length/2 + 1;
            }
            if(total_length  < x){
                if(front.length == 0 && back.length == 0){
                    pushBack(&front, student_id);
                }
                else if(front.length < back.length){
                    int temp = *back.start;
                    popFront(&back);
                    pushBack(&front, temp);
                    pushFront(&back, student_id);
                }
                else{
                    pushFront(&back, student_id);
                    // for(int* i=back.start;i<back.end-1;i++){
                    //     // printf("i - %d", i);
                    //     exchange(i, i+1);
                    // }
                }
            }
           
        } else if (action == 'F') {

            if((front.length) > 0){
                popFront(&front);
                
                
            }
            else if (back.length > 0){
                popFront(&back);
                
            }
            else{
                printf("empty\n");
            }
        } else if (action == 'L') {
            // printf("Entered here");
            if(back.length > 0){
                popBack(&back);
                
            }
            else if(front.length > 0){
                popBack(&front);
                
            }
        }
        // printInOrder(&front);
        // printInOrder(&back);
    }
    if(front.length == 0){
        front.start++;
    }
    if(back.length == 0){
        back.start++;
    }
    // Free allocated memory
    free(front.head);

    free(back.head);


    return 0;
}