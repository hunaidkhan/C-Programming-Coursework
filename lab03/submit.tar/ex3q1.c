#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(){
    srand(time(NULL));
    int p1lives = 0;
    int p2lives = 0;
    p2lives = 3;
    p1lives = 3;
    int p1score = 0;
    int p2score = 0;
    int turn = 0;
 //this is done since the remainder when dividing with 6 will never be more than 6 - only till 5. Hence, 1 is added to increase the range to 6.
   

    while(p1lives>0 && p2lives>0){
        for(int i=0;i<3;i++){
            char choice= ' ';
            printf("Turn %d player %d: ", i+1, turn+1);
            scanf("%c", &choice);
        
            if(choice=='s'){
                getchar();
                break;
            }
            else{
       
                int rolls[3] = {};
             
                for(int i =0; i<3;i++){
                    rolls[i] = (rand()%6)+1;
                }
    
                //bubble sorting the rolls array
                for(int i = 0; i<3;i++){
                    for(int j=0; j<2-i;j++){
                        if(rolls[j]>rolls[j+1]){
                            int initial_element = rolls[j];
                            rolls[j] = rolls[j+1];
                            rolls[j+1] = initial_element;
                        }
                    }
                }
                //calculating points
                int score = 0;
                if(rolls[0]==rolls[1] && rolls[1]==rolls[2]){
                    for(int i =1;i <= 6; i++){
                        if(rolls[1]==i){
                            score = 1000 - i;
                        }
                    }
                   
                }
                else if(rolls[0] == 1 && rolls[1] == 2 && rolls[2] == 3){
                    score = 993;
                }
                else if(rolls[0] == 4 && rolls[1] == 5 && rolls[2] == 6){
                    score = 1000;
                }
                else{
                    score = 100*rolls[2] + 10*rolls[1] + rolls[0];
                }
                printf("You rolled: %d %d %d = %d points", rolls[0], rolls[1], rolls[2], score);
                if(turn == 0){
                    p1score = score;
                }
                else if(turn == 1){
                    p2score = score;
                }
                printf("\n");

            }
            getchar();
        }

        if(turn == 1){
            if(p1score > p2score){
                printf("Player 1 wins this round with %d points\n", p1score);
                p2lives -= 1;
            }
            else if(p1score < p2score){
                printf("Player 2 wins this round with %d points\n", p2score);
                p1lives -= 1;
            }
            else if (p1score== p2score){
                printf("Both players tied this round with %d points\n", p1score);
            }
            printf("Player 1 lives = %d\n", p1lives);
            printf("Player 2 lives = %d\n", p2lives);
            printf("\n");
        }
        turn = (turn+1)%2; //switching turns
        // getchar();

    }
    if(p1lives > 0){
        printf("Player 1 wins!");
    }
    else if(p2lives > 0){
        printf("Player 2 wins!");
    }

}