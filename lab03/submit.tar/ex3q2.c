#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int main(){
    int max = INT_MIN;
    int min = INT_MAX;
    int x =0;
    int y=0;
    int numbers[22] = {}; //initialize array

    printf("Enter 22 integers: ");

    for(int i=0;i<22;i++){
        if(scanf("%d ", &numbers[i])!=1){ //checks for invalid input
            exit(100);
        }
    }

    x = numbers[20];
    y = numbers[21];

    for(int i =0;i < 20; i++){
        if(numbers[i]>max){
            max=numbers[i];
        }
        if(numbers[i] < min){
            min = numbers[i];
        }

    }
    printf("x * max + y * min: %d\n", (x * max + y * min));

}