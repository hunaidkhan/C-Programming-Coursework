#include <stdio.h>
#include <stdlib.h>

int main() {
    int numAisles;
    scanf("%d", &numAisles);

    // Allocate memory for aisles

    char **aisles = (char **)malloc(numAisles * sizeof(char *));
    // int *numAisles = (int *)malloc(numAisles * sizeof(int *));
    int serialCode;
    char productName;
    //allocating memory for each aisle
    for(int i =0;i<numAisles;i++){
        aisles[i] = (char *)malloc(sizeof(char));
        aisles[i][0] = '\0';
    }
    
    while(1){
        if(scanf("%d ", &serialCode)!=1){
            break;
        }
        
        if(serialCode == 0){ //print aisle
   
            int printedNumber=0;
            int aisleSize = 0;
            scanf("%d", &printedNumber);
            while(aisles[printedNumber][aisleSize] != '\0'){
                aisleSize++;
            }
            for(int i =0; i<aisleSize; i++){
                // printf("i=%d c=%c", i,aisles[printedNumber][i]);
                printf("%c", aisles[printedNumber][i]);
            }
            printf("\n");
            continue;
        }
        
        scanf("%c", &productName);
      
        int aisle = serialCode%numAisles;
        
        int aisleSize = 0;
        while(aisles[aisle][aisleSize] != '\0'){
            aisleSize++;
        }
        int newLength = aisleSize + (2*sizeof(char));
        aisles[aisle] = (char *)realloc(aisles[aisle], newLength);
        aisles[aisle][newLength - 2] = productName;
        aisles[aisle][newLength -1] = '\0';
        // for(int i =0; i<newLength;i++){
        //     printf("\n %c", aisles[aisle][i]);
        // }
        // printf("Reached end - %c", aisles[aisle][sizeof(aisles[aisle])-1]);
        
    }
    //freeing blocks of memory to avoid memory leaks
    for (int i = 0; i < numAisles; i++) {
        free(aisles[i]);
    }
    free(aisles);
   
    
}