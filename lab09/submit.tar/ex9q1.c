#include <stdlib.h>
#include <string.h>
#include <stdio.h>

void readLine(char **sentence, int n){ //from textbook
  
   for(int i=0;i<n;i++){
        scanf("%s", sentence[i]);
    }
}

int minimum(int a, int b, int c) {
    int min = a;
    if (b < min) {
        min = b;
    }
    if (c < min) {
        min = c;
    }
    return min;
}

int levenshteinDistance(char *string_a, char *string_b){ //using wikipedia pesudocode
    int m = strlen(string_a);
    int n = strlen(string_b);
    int d[m+1][n+1];

    for (int i = 0; i <= m; i++) {
        for (int j = 0; j <= n; j++) {
            d[i][j] = 0;
        }
    }
    for(int i=1;i<=m;i++){
        d[i][0] = i;
    }
    for(int j=1;j<=n;j++){
        d[0][j] = j;
    }

    for(int j=1;j<=n;j++){
        for(int i=1;i<=m;i++){
            int substitutionCost = (string_a[i - 1] == string_b[j - 1]) ? 0 : 1;
            d[i][j] = minimum(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + substitutionCost);
        }
    }
    return d[m][n];
}




int main(void) {
    int n,m;
    scanf("%d %d", &n, &m);
    char **dictionary = (char **)malloc(n*sizeof(char *));
    for(int i=0;i<n;i++){
        dictionary[i] = (char *)malloc(sizeof(char)*10); 
    }
    // for(int i=0;i<n;i++){
    //     scanf("%s", sentence[i]);
    // }
    readLine(dictionary, n);

    // printf("%c", dictionary[0][1]);

    for(int i=0;i<m;i++){
        char **sentence = (char**)malloc(10*sizeof(char*));
        
        for(int j=0;j<10;j++){
            sentence[j] = (char *)malloc(sizeof(char)*10);
        }
        // int words = 0;
      
            int index = 0;
        while(scanf("%s", sentence[index])!=0){
            
            // printf("Sentence- %s", sentence[i]);
            //check if that words in dictionary or not.
            int present_flag = 0;
            for(int j=0;j<n;j++){
                
                if(strcmp(sentence[index], dictionary[j])==0){
                    // printf("%s is present in dictionary", sentence[i]);
                    present_flag = 1;
                    // words++;
                    printf("%s", sentence[index]);
                    continue;
                }
            }
             
            //if not in dictionary, find the closest word in dictionary using levenshtein distance
            if(present_flag == 0){
                // printf("NOt in dictionary");
                int min = __INT_MAX__;
                int min_index = 0;
                
                for(int j=0;j<n;j++){
                    int distance = levenshteinDistance(sentence[index], dictionary[j]);
                    if (distance < min){
                        min = distance;
                        min_index =j;
                    }
                    // printf("%d", distance);
                }
                // printf("%s is closest to %s",sentence[i],dictionary[index]);
                printf("%s", dictionary[min_index]);
                // words++; 
            }
            int ch = 0;
            if((ch = getchar()) == '\n'){
                break;
            }
            printf(" ");
           
        }
        for(int i=0;i<10;i++){
            free(sentence[i]);
        }
        free(sentence);
      
        printf("\n");
        
      

    }
    for(int i=0;i<n;i++){
        free(dictionary[i]);
        }
    free(dictionary);

    }