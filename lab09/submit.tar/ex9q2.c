#include <stdlib.h>
#include <string.h>
#include <stdio.h>


void add(char *string_a, char *string_b){
    //add two numbers in the form of strings
    long long int length_a = strlen(string_a);
    long long int length_b = strlen(string_b);
    long long int bigger_length = (length_a>length_b) ? length_a : length_b;

    int carry_over = 0;
    int sum = 0;
    int result[bigger_length+1];
    int result_length = 0;
    for(int i=0;i<bigger_length;i++){
        int a = (i<length_a) ? string_a[length_a-i-1] - '0' : 0;
        int b = (i<length_b) ? string_b[length_b-i-1] - '0' : 0;
        sum = a + b + carry_over;
        carry_over = sum/10;
        result[i] = sum%10;
        result_length++;
    }
    // for(int i = bigger_length-1;i >= 0;i--){
    //     int a = (i<length_a) ? string_a[length_a-i-1] - '0' : 0;
    //     int b = (i<length_b) ? string_b[length_b-i-1] - '0' : 0;
    //     sum = a + b + carry;
    //     carry = sum/10;
    //     result[i] = sum%10;
    //     result_length++;
    //     // printf("a- %d, b - %d, sum - %d, result[i] %d", a, b, sum, result[i]);
    // }
    if(carry_over!=0){
        result[result_length] = carry_over;
        result_length++;
    }
    for(int i=result_length-1;i>=0;i--){
        printf("%d", result[i]);
    }
}

void concat(char *string_a, char *string_b){
    //concatenate two strings
    int length_a = strlen(string_a);
    int length_b = strlen(string_b);
    int result_length = length_a + length_b;
    char result[result_length];
    for(int i=0;i<length_a;i++){
        result[i] = string_a[i];
    }
    for(int i=0;i<length_b;i++){
        result[length_a+i] = string_b[i];
    }
    for(int i=0;i<result_length;i++){
        printf("%c", result[i]);
    }
}

void rotate(char *string_a, char *string_b){ 
    //rotate string_a by string_b
    int length_a = strlen(string_a);
    int length_b = strlen(string_b);
    int rotation = 0;
    if(strcmp(string_a, "0")==0){
        printf("0");
        return;
    }
    for(int i=0;i<length_b;i++){ //converting right string to int for operations
        rotation = rotation*10 + (string_b[i] - '0');
    }
    rotation = rotation%length_a; //to reduce number of rotations required to less than length of string.
    char result[length_a];
    for(int i=0;i<length_a;i++){
        result[i] = string_a[(i+rotation)%length_a];
    }

    //ignore the leading zeros and print the result
    if(length_a == 1){
        printf("%c", result[0]);
    }
    int flag = 0; //to prevent deleting zeroes from the middle of the number
    for(int i=0;i<length_a;i++){
        if(result[i] == '0' && flag == 0){
            continue;
        }
        flag = 1;
        printf("%c", result[i]);
    }
    

}

int main(){
    int n;
    scanf("%d\n", &n);
    for(int i=0;i<n;i++){
        char ch;
        int size_a = sizeof(char)*1;
        int size_b = sizeof(char)*1;
        // int size_operator = sizeof(char)*1;
        char* string_a = (char*)malloc(size_a);
        char* string_b = (char*)malloc(size_b);
        // char* operator= (char *)malloc(size_operator);
        char operator[4];
        string_a[size_a-1] = '\0';
        string_b[size_b-1] = '\0';
        // operator[size_operator-1] = '\0';
        int string_b_flag = 0;
        while((ch = getchar()) != '\n'){

            if(string_b_flag==1){
                size_b += sizeof(char);
                string_b = realloc(string_b, size_b);
                string_b[size_b-2] = ch;
                string_b[size_b-1] = '\0';
                continue;
            }
            if(ch == ' '){
                scanf("%s ", operator);
                // size_operator = strlen(cha)*sizeof(char) + 1;
                // operator = realloc(operator, size_operator);
                // operator = cha;
                // printf("OPERATOR _ %s\n", operator);
                string_b_flag = 1;
                continue;

            }
            size_a += sizeof(char);
            string_a = realloc(string_a, size_a);
            string_a[size_a-2] = ch;
            string_a[size_a-1] = '\0';
        }
        //carry out operation
        // printf("STRIN a - %s", string_a);
        // printf("STRIN a  - %s", string_b);
        // printf("STRIN a  - %s", operator);
        if(strcmp(operator, "+")==0){
            add(string_a, string_b);
        }
        if(strcmp(operator, "@")==0){
            concat(string_a, string_b);
        }
        if(strcmp(operator, "rot") == 0){
            rotate(string_a, string_b);
        }
        printf("\n");
        free(string_a);
        free(string_b);
        // free(operator);
        // printf("Stirng a - %s", string_a);
        // printf("operartotr - %s", operator);
        // printf("Stirng b - %s", string_b);
       
    }
}