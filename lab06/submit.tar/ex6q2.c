#include "ex6q2.h"

// Please don't change anything in this main function!
int main(void) {
    if (!test_bubble(bubble_sort))
        fprintf(stderr, "Bubble sorting failed\n");
    if (!test_gnome(gnome_sort))
        fprintf(stderr, "Gnome sorting failed\n");
    if (!test_insertion(insertion_sort))
        fprintf(stderr, "Insertion sorting failed\n");
    if (!test_custom(custom_sort)) {
        fprintf(stderr, "Custom sorting failed\n");
	}
	return 0;
}


void bubble_sort(int n, int arr[n]) {
    //https://www.geeksforgeeks.org/bubble-sort/
    for(int i =0;i<n-1;i++){
        for(int j =0;j<n-i-1;j++){
            if(arr[j]>arr[j+1]){
                int temporary_variable = arr[j+1];
                arr[j+1] = arr[j];
                arr[j] = temporary_variable;
            }
        }
    }
}

// Not very well known, but very easy!
// Check out the description on here https://en.wikipedia.org/wiki/Gnome_sort
void gnome_sort(int n, int arr[n]) {
    int index = 0;
    while(index < n){
        if(index == 0){
            index++; //move one step ahead if at the start of the array
        }
        if(arr[index] >= arr[index-1]){ //if previous element is smaller then proceed
            index++;
        }
        else if(arr[index]<arr[index-1]){ //if previous element is bigger, then swap and step backward
            int temp = arr[index];
            arr[index] = arr[index-1];
            arr[index-1] = temp; 
            index--;
        }
    }
}

void insertion_sort(int n, int arr[n]) {
    for(int j=1;j<n;j++){
        int flag = arr[j];
        int i = j-1;
        while(i>=0 && arr[i]>flag){
            arr[i+1] = arr[i];
            i--;
        }
        arr[i+1] = flag;
    }
}


// The sort you found! (See lab description for details)
void custom_sort(int n, int arr[n]) {
    //used cocktail shaker sort: 
    //https://en.wikipedia.org/wiki/Cocktail_shaker_sort
    int swapped = 1;

    int startIndex = 0;
    int endIndex = n-1;

    while(swapped){
        swapped = 0;
        
        for(int i=0;i<endIndex;i++){
            if(arr[i] > arr[i+1]){
                int temp = arr[i];
                arr[i] = arr[i+1];
                arr[i+1] = temp;
                swapped = 1;
            }
        }

        if(swapped == 0){ //means array is already sorted if no swap is performed
            break;
        }

        swapped = 0;

        endIndex = endIndex-1;
        //loops through the array in reverse
        for(int i =endIndex-1;i>=startIndex;--i){
            if(arr[i] > arr[i+1]){
                int temp = arr[i];
                arr[i] = arr[i+1];
                arr[i+1] = temp;
                swapped = 1;
            }
        }
        ++startIndex;
    }
   
}
