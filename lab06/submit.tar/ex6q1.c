#include "ex6q1.h"
#include <math.h>

#define LEN 200000000
uint32_t MEMO[LEN];
int count = 0;

// This function should be pure recursion - no dynamic programming allowed
uint32_t exp_mod_1(uint32_t base, uint32_t exp, uint32_t modulo) {
    //keep splitting the exponent in half until it reaches 1
    EXP_MOD_1_CALL_COUNT++;
    if(exp == 1){
        return (base%modulo);
    }
    int first_half = exp/2;
    int second_half = exp - first_half;

    return (exp_mod_1(base, first_half, modulo)%modulo * exp_mod_1(base, second_half, modulo)%modulo) % modulo;
}

// This function should store the values of previous calls to exp_mod_2 in an
// array and use them for later calculations.
uint32_t exp_mod_2(uint32_t base, uint32_t exp, uint32_t modulo) {
    EXP_MOD_2_CALL_COUNT++;
    if(exp == 1){
        return (base%modulo);
    }
    //extract computed value from array
    if(MEMO[exp] > 0){
        return MEMO[exp]%modulo;
    }
    
    int first_half = exp/2;
    int second_half = exp - first_half;
    //insert computed exponent values in the array
    MEMO[exp] = (exp_mod_2(base, first_half, modulo)%modulo * exp_mod_2(base, second_half, modulo)%modulo);
    return MEMO[exp]%modulo;
}

int main(void) {
    uint32_t base, exp, modulo;

    if (scanf("%d %d %d", &base, &exp, &modulo) != 3) {
        return 1;
    }

    uint32_t mod_1 = exp_mod_1(base, exp, modulo);
    uint32_t mod_2 = exp_mod_2(base, exp, modulo);

    fprintf(stdout, "exp_mod_1 calls: %d\n", EXP_MOD_1_CALL_COUNT);
    fprintf(stdout, "exp_mod_2 calls: %d\n", EXP_MOD_2_CALL_COUNT);
    fprintf(stdout, "%d == %d\n", mod_1, mod_2);
	return 0;
}
