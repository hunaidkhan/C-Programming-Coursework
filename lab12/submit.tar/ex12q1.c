#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
//https://www.tutorialspoint.com/cprogramming/c_bitwise_operators.htm


typedef uint32_t NewFloat;
#define MY_INFINITY 1.0 / 0.0

double powerOfTwo(int x) {
    double result = 1.0;
    for (int i = 0; i < x; ++i) {
        result *= 2.0;
    }
    return result;
}

NewFloat bits_string_to_nfloat(char* s1){

    NewFloat result = 0;
    for (int i = 0; i < 32; ++i) {
        result = (result << 1) | (s1[i] - '0');
    }
    return result;
}

void nfloat_debug(NewFloat f){
    for (int i = 31; i >= 0; --i) {

        printf("%d", (f >> i) & 1);
        if(i==31){
            printf(" ");
        }
        if(i==26){
            printf(" ");
        }
    }
    printf("\n");
} //part 1

NewFloat float_to_nfloat(float f){

    NewFloat result = 0;
    int *integerPart = (int *)&f;
   

    uint32_t sign = (*integerPart >> 31) & 1;
    uint32_t exponent = (*integerPart >> 23) & 0x1F;
    uint32_t biasedExp = exponent - 127+ 15; 

    uint32_t fractionPart = *integerPart &  0x7FFFFF;
    // printf("%d %d %d\n", sign<<31, biasedExp << 26, fractionPart);
    result = (sign << 31) | (biasedExp << 26) | (fractionPart) << 3;

 

    return result;

} //part 2



double power(int base,int exponent){
    double x = 1.00;
    double reciprocal = (double)base;
    if (exponent<0){
        reciprocal = 1/reciprocal;
        exponent *= -1;
    }
    int i =1;
    while(i<exponent){
        x *= reciprocal;
        i++;
    }

    return x;
}

double getDecimal(int fraction, int exp){
    double decimal = 0;

    if (exp >= 0){
        int i =0;
        while(i < 26-exp){
            if (((fraction >> (25- exp - i)) & 1) == 1) {
            decimal += power(2, ((i+1)*-1)); 
            }
            i++;
    }}
    else{
        int fraction = 0;
        if (exp != -15){
             fraction = fraction | 1 << 26;
        }
        fraction |= fraction & 0x3ffffff;
        int i =0;
        while(i<27){
        if(((fraction >> (26- i)) & 1) == 1) {
      
            decimal = decimal+ power(2, ((i+(-exp))*-1)); 
        }
        i++;
    }
    }
    
    return decimal;
}

int getIntegral(int fraction, int exp){
    int integral = 0;
    if(exp<0){
        integral = 0;
    }
    else if (exp >= 0){
    integral = integral | 1 << (exp);  
    integral |= fraction >> (26 - exp); 
    }

    return integral;
}

void nfloat_print(NewFloat f){ //part 3
    int sign = (f >> 31) &1;
    int exp = ((f >> 26) & 0x1f)-15;
    int fraction = (f & 0x3ffffff);
  
    // printf("%d %d %d\n", sign, b_exp, mantissa);
    int integral = getIntegral(fraction, exp);
    float decimal = getDecimal(fraction, exp);
    
    float result = 0;
    if(sign == 1){
         result = -1.0;
    }
    else{
         result = 1.0;
    }
     
    result *= (float)integral + decimal;

    printf("%.7f\n", result);
}

NewFloat nfloat_double(NewFloat f){ //part 4
    int sign = (f >> 31) &1;
    int b_exp = ((f >> 26) & 0x1f)-15;
    int mantissa = (f & 0x3ffffff);

    int integral = getIntegral(mantissa, b_exp);
    double decimal = getDecimal(mantissa, b_exp);

    double result = 0;
    if(sign == 1){
        result = -1.0;
    }
    else{
        result = 1.0;
    }
    result *= (double)integral + decimal;

    NewFloat final_f = float_to_nfloat(result*2);
    return final_f;
}
NewFloat nfloat_add(NewFloat a, NewFloat b){
    int signA = (a >> 31) &1;
    int expA = ((a >> 26) & 0x1f)-15;
    int fractionA = (a & 0x3ffffff);

    int integralA = getIntegral(fractionA, expA);
    double decimalA = getDecimal(fractionA, expA);

    double first_result = 0;
    if(signA == 1){
        first_result = -1.0;
    }
    else{
        first_result = 1.0;
    }

    first_result *= ((double)integralA + decimalA);

    int signB = (b >> 31) &1;
    int expB = ((b >> 26) & 0x1f)-15;
    int fractionB = (b & 0x3ffffff);

    int integralB = getIntegral(fractionB, expB);
    double decimalB = getDecimal(fractionB, expB);
    double second_result =0;
    if(signB==1){
        second_result = -1.0;
    }
    else{
        second_result = 1.0;
    }
    second_result *= (double)integralB + decimalB;
    NewFloat new_f = float_to_nfloat(first_result + second_result);
    return new_f;
}


int main(void) {
    int part_num;
    char s1[40];
    float f1, f2;
    NewFloat n1, n2;

    // This will scan the input for you! Uncomment pieces once you implement
    // the functions for that part
    while (1) {
        int res = scanf(" p%d", &part_num);

        if (res != 1) {
            break;
        } else if (part_num == 1) {
            scanf("%s", s1);
            n1 = bits_string_to_nfloat(s1);
            nfloat_debug(n1);
        } else if (part_num == 2) {
            scanf("%f", &f1);
            n1 = float_to_nfloat(f1);
            nfloat_debug(n1);
        } else if (part_num == 3) {
            scanf("%s", s1);
            n1 = bits_string_to_nfloat(s1);
            nfloat_print(n1);
        } else {
            scanf("%s ", s1);

            if (s1[0] == 'd') {
                scanf("%f", &f1);
                n1 = float_to_nfloat(f1);
                n1 = nfloat_double(n1);
            } else {
                scanf("%f %f", &f1, &f2);
                n1 = float_to_nfloat(f1);
                n2 = float_to_nfloat(f2);
                n1 = nfloat_add(n1, n2);
            }

            nfloat_print(n1);
        }
    }
}
