/* Purpose: Solving magic square
 * Author:
 * Date:
 * References:
 */

#include "lab05.h"
int isSafe(int n, int grid[n][n], int num, int row, int col) { //helper function to check if the proposed num value is unique
    // Checks for the uniqueness of the proposed num value by the loop in magic function
    for (int x = 0; x < n; x++) {
        if (grid[row][x] == num || grid[x][col] == num) { //checks the row and column
            return 0;
        }
    }
    return 1;
}
// Do not touch anything in this main function (used for testing purposes)
int main(void) {
    return test_magic(magic);
}

// This function is a non-recursive function that checks whether a given grid[n][n] is a magic square.
// Complete the function definition:
int check(int n, int grid[n][n]) {
    // double sumCheck = (n/2)*(n*n+1);
    // printf("n-%d",n);
    // printf("sumCheck-%lf\n",sumCheck);
    

        int uniqueVal[n*n+1];

        for(int i=1;i<n*n+1;i++){ //initialising the array to 0 due to variable length array
            uniqueVal[i] = 0;
        }

        //checking unique values

        for(int i=0;i<n;i++){
            for(int j=0;j<n;j++){
                if(grid[i][j]<1 || grid[i][j]>n*n){ //checking if the values are within the range
                // printf("33 - %d, i - %d, j - %d", grid[i][j],i,j);
                return 0;
            }
            if(uniqueVal[grid[i][j]]){ //if value is already present in the unique values array
                // printf("37");
                return 0;
            }
                uniqueVal[grid[i][j]] = 1;
            }
        }
        // printf("SDSD");

        //checking row sum
        int firstRowSum = 0;
        
        for(int j=0;j<n;j++){
            firstRowSum += grid[0][j];
        }
        
        for(int i=0;i<n;i++){
            int rowSum = 0;
            int colSum = 0;
            for(int j=0;j<n;j++){
                rowSum += grid[i][j];
                colSum += grid[j][i];
            }
            if(rowSum != firstRowSum || colSum != firstRowSum){
                // printf("51 - %d - %lf", rowSum, sumCheck);
                return 0;
            }
        }

        //checking left diagonal sum
        int leftDiagonalSum = 0;
        for(int i=0;i<n;i++){
            leftDiagonalSum += grid[i][i];
            
        }
        if(leftDiagonalSum != firstRowSum){
            // printf("75");
                return 0;
            }

        //checking right diagonal sum
        int rightDiagonalSum = 0;
        for(int i=0;i<n;i++){
            rightDiagonalSum += grid[i][n-i-1];
            
        }
        if(rightDiagonalSum != firstRowSum){
            // printf("75");
            return 0;
        }
        if(leftDiagonalSum != rightDiagonalSum){
            // printf("90");
            return 0;
        } 
    // printf("REACHE END");
    return 1;
    }



// This function is a recursive function that intends to solve a given grid[n][n] as in the lab05 description.
// Complete the function definition:
int magic(int n, int grid[n][n]) {
    int row = -1; //this is to set the row and col to a number not recongnized by indices of the grid
    int col = -1;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (grid[i][j] == 0) {
                row = i;
                col = j;
                break;
            }
        }
        if (row != -1) { //completely breaking out of the nested for loops
            break;
        }
    }
    // printf("I am here");
    // Base case: If all cells are filled and check returns true
   
    if(row == -1){
        // printf("Array has been filled");
        return check(n,grid);
    }
    // printf("\n locaitnn of emplty celels - a[%d][%d]", row, col);
    // now we know we need to fill some empty cells
    for (int num = 1; num <= n*n; num++) { //this is the range of magic square cells
        if (isSafe(n, grid, num, row, col)) {
            grid[row][col] = num;
            // Recursive call to the next empty cell
            if (magic(n, grid)) {
                return 1;
            }
            // if this number doesnt work, the check doesnt pass - backtrack
            grid[row][col] = 0;
        }
    }
    // No possible solution. End here.
    return 0;
}
