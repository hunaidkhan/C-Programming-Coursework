#ifndef LAB05_H
#define LAB05_H
#include <stdio.h>

int test_magic(int (*magic)(int n, int[n][n]));

int magic(int n, int grid[n][n]);

int check(int n, int grid[n][n]);

#endif

