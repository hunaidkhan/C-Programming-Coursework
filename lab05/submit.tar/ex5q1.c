#include <stdio.h>

int boxChecker(int puzzle[9][9]){
        
    for(int i =0;i<9;i++){
        for(int j=0;j<9;j++){
            int boxCheck[9]={0};
            int row = (i/3)*3;
            int column = (j/3)*3;
            for(int k=row;k<row+3;k++){ //traverses through the box and checks if there are any duplicates
                for(int l=column;l<column+3;l++){
                    int index = puzzle[k][l];
                    boxCheck[index-1] += 1;
                }
            }
            for(int k=0;k<9;k++){
                if(boxCheck[k] != 1){
                    return 0;
                }
            }
        }
    }
    
    return 1;
}

int columnChecker(int puzzle[9][9]){
    for(int i = 0; i < 9; i++){
        int columnCheck[9] = {0};
        for(int j = 0; j < 9; j++){
            int index = puzzle[j][i];
            columnCheck[index-1] += 1;
        }
        for(int j = 0; j < 9; j++){
            if(columnCheck[j] != 1){
                return 0;
            }
        }
    }
    return 1;
}

int rowChecker(int puzzle[9][9]){

   
    for(int i=0;i<9;i++){
    int rowCheck[9]={0};
        for(int j=0;j<9;j++){ //traverses through the whole row and checks if there are any duplicates
            int index = puzzle[i][j];
            rowCheck[index-1] += 1;
        }

        for(int j=0;j<9;j++){ //returns after each row if there are any duplicates
            if(rowCheck[j] != 1){
                return 0;
            }
        }
    }
    return 1;
}

int main() {
    
   
    int sudoku[9][9]={0}; // Two-dimensional array to store the numbers
    for(int i=0;i<9;i++){
        for(int j=0;j<9;j++){
            scanf("%1d",&sudoku[i][j]);
        }
    }

    // for(int i=0;i<9;i++){
    //     for(int j=0;j<9;j++){
    //         printf("%d ",sudoku[i][j]);
    //     }
    //     printf("\n");
    // }

    if(rowChecker(sudoku)&& columnChecker(sudoku) && boxChecker(sudoku)){
        printf("Valid\n");
    }
    else{
        printf("Invalid\n");
    }
}